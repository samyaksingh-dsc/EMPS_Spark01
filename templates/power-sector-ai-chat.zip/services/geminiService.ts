
import { GoogleGenAI, Chat, History, GenerateContentRequest, Part } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const systemInstruction = "You are an expert AI assistant specializing in the global power and energy sector. Provide detailed, accurate, and up-to-date information. Your knowledge covers market analysis, regulations, technology, renewable energy, grid management, and pricing mechanisms like Day-Ahead Market (DAM) and Green Day-Ahead Market (GDAM). When asked about recent data or news, use your search capabilities to find the latest information. Format your responses clearly using markdown when appropriate.";

const getModel = (isThinkingMode: boolean) => {
    return isThinkingMode ? 'gemini-2.5-pro' : 'gemini-2.5-flash';
};

let chats: { [key: string]: Chat } = {};

const getChatSession = (isThinkingMode: boolean): Chat => {
    const modelName = getModel(isThinkingMode);
    if (!chats[modelName]) {
        chats[modelName] = ai.chats.create({
            model: modelName,
            config: {
                systemInstruction: systemInstruction,
                ...(isThinkingMode && { thinkingConfig: { thinkingBudget: 32768 } })
            },
        });
    }
    return chats[modelName];
};


export const generateChatResponse = async (
  history: History,
  prompt: string,
  isThinkingMode: boolean
): Promise<string> => {
    try {
        const chat = getChatSession(isThinkingMode);
        const result = await chat.sendMessage({ message: prompt });
        return result.text;
    } catch (error) {
        console.error("Gemini API call failed:", error);
        // Invalidate chat session on error
        const modelName = getModel(isThinkingMode);
        delete chats[modelName];
        throw error;
    }
};
