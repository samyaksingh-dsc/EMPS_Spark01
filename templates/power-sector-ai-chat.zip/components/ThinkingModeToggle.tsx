
import React from 'react';
import { BoltIcon } from './icons/BoltIcon';

interface ThinkingModeToggleProps {
  isEnabled: boolean;
  onToggle: () => void;
}

const ThinkingModeToggle: React.FC<ThinkingModeToggleProps> = ({ isEnabled, onToggle }) => {
  return (
    <div className="flex items-center space-x-3">
        <span className={`text-sm font-medium ${isEnabled ? 'text-purple-400' : 'text-gray-400'}`}>
            Thinking Mode
        </span>
        <button
            onClick={onToggle}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500 ${
            isEnabled ? 'bg-purple-600' : 'bg-gray-600'
            }`}
        >
            <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-300 ${
                isEnabled ? 'translate-x-6' : 'translate-x-1'
            }`}
            />
        </button>
        <div className={`p-1 rounded-full transition-all duration-300 ${isEnabled ? 'bg-purple-500/20' : 'bg-gray-500/10'}`}>
            <BoltIcon className={`w-5 h-5 transition-colors duration-300 ${isEnabled ? 'text-purple-400' : 'text-gray-500'}`} />
        </div>
    </div>
  );
};

export default ThinkingModeToggle;
