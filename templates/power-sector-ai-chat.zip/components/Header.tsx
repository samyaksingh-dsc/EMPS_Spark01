
import React from 'react';
import ThinkingModeToggle from './ThinkingModeToggle';
import { BoltIcon } from './icons/BoltIcon';

interface HeaderProps {
  isThinkingMode: boolean;
  onToggleThinkingMode: () => void;
}

const Header: React.FC<HeaderProps> = ({ isThinkingMode, onToggleThinkingMode }) => {
  return (
    <header className="flex items-center justify-between p-4 bg-gray-800/80 backdrop-blur-md shadow-lg border-b border-gray-700 sticky top-0 z-10">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-blue-500/20 rounded-lg">
          <BoltIcon className="w-6 h-6 text-blue-400" />
        </div>
        <h1 className="text-xl font-bold text-white tracking-wide">
          Power Sector AI Chat
        </h1>
      </div>
      <ThinkingModeToggle
        isEnabled={isThinkingMode}
        onToggle={onToggleThinkingMode}
      />
    </header>
  );
};

export default Header;
