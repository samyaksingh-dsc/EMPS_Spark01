import React from 'react';
import { Message } from '../types';
import { BotIcon } from './icons/BotIcon';
import { UserIcon } from './icons/UserIcon';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';


const ChatMessage: React.FC<{ message: Message }> = ({ message }) => {
  const isModel = message.role === 'model';

  return (
    <div className={`flex items-start gap-4 ${isModel ? '' : 'flex-row-reverse'}`}>
      <div
        className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center shadow-md ${
          isModel ? 'bg-gradient-to-tr from-blue-500 to-teal-400' : 'bg-gray-700'
        }`}
      >
        {isModel ? <BotIcon className="w-5 h-5 text-white" /> : <UserIcon className="w-5 h-5 text-gray-300" />}
      </div>
      <div
        className={`max-w-xl md:max-w-2xl lg:max-w-3xl px-4 py-3 rounded-xl shadow-md ${
          isModel ? 'bg-gray-800 text-gray-200' : 'bg-blue-600 text-white'
        }`}
      >
        <div className="prose prose-sm prose-invert max-w-none 
                        prose-p:text-inherit prose-headings:text-inherit 
                        prose-strong:text-inherit prose-em:text-inherit 
                        prose-code:text-inherit prose-pre:bg-black/20 
                        prose-a:text-blue-400 hover:prose-a:text-blue-300">
           <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {message.content}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;