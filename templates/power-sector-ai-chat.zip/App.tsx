
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Message } from './types';
import Header from './components/Header';
import MessageList from './components/MessageList';
import ChatInput from './components/ChatInput';
import { generateChatResponse } from './services/geminiService';
import { History } from '@google/genai';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      content: "Hello! I am your AI assistant for the power sector. How can I help you today? You can ask me about DAM/GDAM rates, market trends, or any other related topic.",
      timestamp: new Date(),
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const chatHistoryRef = useRef<History>([]);

  useEffect(() => {
    // Reset history if thinking mode changes to ensure the correct model context is used.
    chatHistoryRef.current = [];
    setMessages(prev => [prev[0]]); // Keep the initial greeting message
  }, [isThinkingMode]);


  const handleSendMessage = useCallback(async (inputText: string) => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      role: 'user',
      content: inputText,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    setError(null);

    try {
      const responseText = await generateChatResponse(chatHistoryRef.current, inputText, isThinkingMode);
      
      const modelMessage: Message = {
        role: 'model',
        content: responseText,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, modelMessage]);

    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to get response from AI. Please try again. Error: ${errorMessage}`);
       const errorModelMessage: Message = {
        role: 'model',
        content: `Sorry, I encountered an error. Please check your connection or API key and try again.`,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorModelMessage]);

    } finally {
      setIsLoading(false);
    }
  }, [isThinkingMode]);

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-gray-100 font-sans">
      <Header isThinkingMode={isThinkingMode} onToggleThinkingMode={() => setIsThinkingMode(!isThinkingMode)} />
      <main className="flex-1 overflow-y-auto">
        <MessageList messages={messages} isLoading={isLoading} />
      </main>
      <footer className="bg-gray-900/50 backdrop-blur-sm border-t border-gray-700">
        {error && <div className="bg-red-500/20 text-red-300 p-2 text-center text-sm">{error}</div>}
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </footer>
    </div>
  );
};

export default App;
